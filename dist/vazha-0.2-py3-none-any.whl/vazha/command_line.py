import vazha

def main():
    vazha.compile()