## Vazha Script

Command line tool for Vazha script

You completely write your code in malayalam and compile it using ```vazha```

### Install

```bash
pip3 install vazha
```
### Code
Write code with extension *.vazha*

Use Vs-code extension ```vazha-sense``` to code faster it has a manglish to vazha script autocomplete feature.

### Run 

```bash
vazha <filepath>
```